package Api;

public class BookAPI {
	 private String coverSmallUrl,title,publisher,author,priceStandard,isbn, link;
	 public String getCoverSmallUrl() {
	  return coverSmallUrl;
	 }
	 public void setCoverSmallUrl(String coverSmallUrl) {
	  this.coverSmallUrl = coverSmallUrl;
	 }
	 public String getTitle() {
	  return title;
	 }
	 public void setTitle(String title) {
	  this.title = title;
	 }
	 public String getPublisher() {
	  return publisher;
	 }
	 public void setPublisher(String publisher) {
	  this.publisher = publisher;
	 }
	 public String getAuthor() {
	  return author;
	 }
	 public void setAuthor(String author) {
	  this.author = author;
	 }
	 public String getPriceStandard() {
	  return priceStandard;
	 }
	 public void setPriceStandard(String priceStandard) {
	  this.priceStandard = priceStandard;
	 }
	 public String getIsbn() {
	  return isbn;
	 }
	 public void setIsbn(String isbn) {
	  this.isbn = isbn;
	 }
	 public String getLink() {
	  return link;
	 }
	 public void setLink(String link) {
	  this.link = link;
	 }
}